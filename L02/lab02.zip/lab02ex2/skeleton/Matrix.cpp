//=====================================================================
// FILE: Matrix.cpp
//=====================================================================

//=====================================================================
// STUDENT NAME: <your name>
// MATRIC NO.  : <matric no.>
// NUS EMAIL   : <your NUS email address>
// COMMENTS TO GRADER:
// <comments to grader, if any>
//
//=====================================================================


#include "Matrix.h"
#include <iostream>

// add other necessary procedures

void Matrix::rotate(int degrees) {
    // transform the matrix by rotating the matrix 

}


void Matrix::reflectX() {
    // transform the matrix by reflecting it about the x-axis

}


void Matrix::reflectY() {
    // transform the matrix by reflecting it about the y-axis

}


void Matrix::operate(string operation, string type) {
    // transform matrix according to input operation and type

}

